Ask user to input a number


def print_a_multiplication_table(number):
Print out the multiplication table using a loop


print_a_multiplication_table(number)