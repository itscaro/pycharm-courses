input_var = input("Enter something: ")
print("You entered: " + input_var)

your_name = Ask the user her/his name
your_age = Ask the user her/his age
your_sex = Ask the user her/his sex
print(Print "Hello <your_name>")
print(Print ""You are <your_age> years old and you are a <your_sex>")
