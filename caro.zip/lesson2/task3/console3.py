print('Do you see the difference? : "%d" vs "%5d" vs "%05d" vs "%.2f" vs "%5.2f" vs "%05.2f"' % (7, 7, 7, 7.0, 7.0, 7.0))

number = input("Which multiplication table you want to print out? ")
number = int(number)


def print_a_multiplication_table(number):
Print out the multiplication table using a loop


print_a_multiplication_table(number)