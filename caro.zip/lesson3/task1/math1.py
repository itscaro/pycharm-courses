def fibo(n):
Calculate the nth number in the Fibonacci sequence

until = int(input("Last number in the fibonacci must be strictly smaller than: "))

Print out the number in a list